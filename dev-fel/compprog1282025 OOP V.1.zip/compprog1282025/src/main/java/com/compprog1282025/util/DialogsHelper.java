/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.compprog1282025.util;

/**
 *
 * @author grazi
 */
import javax.swing.*;
import java.awt.*;

public class DialogsHelper {

    // This makes the pop-up boxes match our custom Midnight Blue theme--update: the color was off
    public static void showInfo(Component parent, String message) {
        UIManager.put("OptionPane.background", Color.WHITE);
        UIManager.put("Panel.background", Color.WHITE);
        UIManager.put("Button.background", UIStyles.PRIMARY_COLOR);
        UIManager.put("Button.foreground", Color.WHITE);
        UIManager.put("Button.font", new Font("Segoe UI", Font.BOLD, 12));

        JOptionPane.showMessageDialog(parent, message, "MotorPH Info", JOptionPane.INFORMATION_MESSAGE);
    }

    public static void showError(Component parent, String message) {
        UIManager.put("Button.background", new Color(178, 34, 34)); // Firebrick Red for errors--for now.
        JOptionPane.showMessageDialog(parent, message, "System Error", JOptionPane.ERROR_MESSAGE);
    }

    public static boolean showConfirm(Component parent, String message) {
        UIManager.put("Button.background", UIStyles.PRIMARY_COLOR);
        int response = JOptionPane.showConfirmDialog(parent, message, "Confirm Action", 
                                                     JOptionPane.YES_NO_OPTION);
        return response == JOptionPane.YES_OPTION;
    }
}