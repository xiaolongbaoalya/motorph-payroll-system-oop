/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.compprog1282025.gui;

/**
 *
 * @author grazi
 */
import com.compprog1282025.util.UIStyles;
import javax.swing.*;
import java.awt.*;

public class LandingPageView extends JPanel {
    // 1. We create a place to STORE the frame
    private JFrame parentFrame; 

    public LandingPageView(JFrame frame) {
        // 2. We save the frame passed from the constructor
        this.parentFrame = frame; 

        setLayout(new GridBagLayout());
        setBackground(Color.WHITE);
        GridBagConstraints gbc = new GridBagConstraints();
        gbc.insets = new Insets(10, 10, 10, 10);
        gbc.fill = GridBagConstraints.HORIZONTAL;

        JLabel title = new JLabel("Welcome to MotorPH", SwingConstants.CENTER);
        title.setFont(new Font("Segoe UI", Font.BOLD, 24));
        gbc.gridy = 0;
        add(title, gbc);

        JButton empBtn = new JButton("Employee Login");
        JButton adminBtn = new JButton("Admin Login");
        UIStyles.styleButton(empBtn);
        UIStyles.styleButton(adminBtn);

        gbc.gridy = 1; add(empBtn, gbc);
        gbc.gridy = 2; add(adminBtn, gbc);

        // 3. Now 'parentFrame' is recognized!
        empBtn.addActionListener(e -> new LoginDialog(parentFrame, "Employee Login", false).setVisible(true));
        adminBtn.addActionListener(e -> new LoginDialog(parentFrame, "Admin Login", true).setVisible(true));
    }
}