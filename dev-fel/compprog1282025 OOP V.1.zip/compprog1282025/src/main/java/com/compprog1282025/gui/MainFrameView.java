/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.compprog1282025.gui;

/**
 *
 * @author grazi
 */
// Swing and AWT are standard Java libraries

import com.compprog1282025.util.ScreenManager;
import javax.swing.*;

public class MainFrameView extends JFrame {

    public MainFrameView() {
        setTitle("MotorPH Payroll System");
        setSize(800, 600);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLocationRelativeTo(null); 

        // We call showPanel directly and pass 'this' (the frame)
        ScreenManager.showPanel(this, new LandingPageView(this));
    }
}