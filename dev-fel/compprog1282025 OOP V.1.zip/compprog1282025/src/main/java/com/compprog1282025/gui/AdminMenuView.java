/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.compprog1282025.gui;

/**
 *
 * @author grazi
 */
import com.compprog1282025.util.ScreenManager;
import com.compprog1282025.util.UIStyles;
import javax.swing.*;
import java.awt.*;

public class AdminMenuView extends JPanel {
    private JFrame frame;

    public AdminMenuView(JFrame frame) {
        this.frame = frame;
        setLayout(new BorderLayout(20, 20));
        setBorder(BorderFactory.createEmptyBorder(40, 40, 40, 40));
        setBackground(Color.WHITE);

        // --- 1. Header ---
        JLabel title = new JLabel("Admin Control Center", SwingConstants.CENTER);
        title.setFont(new Font("Segoe UI", Font.BOLD, 26));
        add(title, BorderLayout.NORTH);

        // --- 2. Button Grid (The Functions) ---
        // This restores the 4 main functions from our God Class
        JPanel grid = new JPanel(new GridLayout(2, 2, 20, 20));
        grid.setOpaque(false);

        JButton btnRegistry = new JButton("Employee Registry");
        JButton btnPayroll = new JButton("Payroll Management");
        JButton btnAttendance = new JButton("Attendance Tracking");
        JButton btnLogout = new JButton("Logout System");

        // Apply Styles
        UIStyles.styleButton(btnRegistry);
        UIStyles.styleButton(btnPayroll);
        UIStyles.styleButton(btnAttendance);
        UIStyles.styleButtonSmall(btnLogout);

        grid.add(btnRegistry);
        grid.add(btnPayroll);
        grid.add(btnAttendance);
        grid.add(btnLogout);

        add(grid, BorderLayout.CENTER);

        // --- 3. Navigation Logic ---
        
        // Opens the Employee List we fixed earlier
        btnRegistry.addActionListener(e -> {
            ScreenManager.showPanel(frame, new EmployeeListView(frame));
        });

        // Placeholder for Payroll (Link this to your PayrollView later)
        btnPayroll.addActionListener(e -> {
            JOptionPane.showMessageDialog(this, "Opening Payroll Module...");
        });

        // Placeholder for Attendance
        btnAttendance.addActionListener(e -> {
            JOptionPane.showMessageDialog(this, "Opening Attendance Module...");
        });

        // Returns to Landing Page
        btnLogout.addActionListener(e -> {
            ScreenManager.showPanel(frame, new LandingPageView(frame));
        });
    }
}