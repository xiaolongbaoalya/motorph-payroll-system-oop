/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.compprog1282025.gui;

/**
 *
 * @author grazi
 */
import com.compprog1282025.util.ScreenManager;
import javax.swing.*;
import java.awt.*;

public class EmployeeDashboardView extends JPanel {

    public EmployeeDashboardView(JFrame frame, String employeeName) {
        setLayout(null); 
        setBackground(new Color(245, 245, 245)); 
        setPreferredSize(new Dimension(800, 600));

        JLabel lblWelcome = new JLabel("Welcome, " + employeeName);
        lblWelcome.setFont(new Font("Segoe UI", Font.BOLD, 24));
        lblWelcome.setBounds(50, 30, 400, 40); 
        add(lblWelcome);

        JLabel lblPosition = new JLabel("Position: Employee");
        lblPosition.setBounds(50, 100, 200, 25);
        add(lblPosition);

        JLabel lblPeriod = new JLabel("Select Period:");
        lblPeriod.setBounds(50, 200, 100, 25);
        add(lblPeriod);

        String[] months = {"January", "February", "March", "April", "May", "June", 
                           "July", "August", "September", "October", "November", "December"};
        JComboBox<String> monthBox = new JComboBox<>(months);
        monthBox.setBounds(150, 200, 120, 25);
        add(monthBox);

        String[] years = {"2024", "2025"};
        JComboBox<String> yearBox = new JComboBox<>(years);
        yearBox.setBounds(280, 200, 80, 25);
        add(yearBox);

        JButton viewSalaryBtn = new JButton("View My Payslip");
        viewSalaryBtn.setBounds(50, 260, 180, 45); 
        viewSalaryBtn.setBackground(new Color(0, 102, 204)); 
        viewSalaryBtn.setForeground(Color.WHITE);
        add(viewSalaryBtn);

        JButton logoutBtn = new JButton("Logout");
        logoutBtn.setBounds(650, 500, 100, 30);
        logoutBtn.setBackground(new Color(220, 53, 69));
        logoutBtn.setForeground(Color.WHITE);
        add(logoutBtn);

        viewSalaryBtn.addActionListener(e -> {
            String period = monthBox.getSelectedItem() + " " + yearBox.getSelectedItem();
            JOptionPane.showMessageDialog(this, "Generating Payslip for " + employeeName + " (" + period + ")");
        });

        logoutBtn.addActionListener(e -> {
            ScreenManager.showPanel(frame, new LandingPageView(frame));
        });
    }
}