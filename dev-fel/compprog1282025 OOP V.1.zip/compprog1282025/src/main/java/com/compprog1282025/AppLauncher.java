/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.compprog1282025;

/**
 *
 * @author grazi
 */
import com.compprog1282025.gui.MainFrameView;
import javax.swing.SwingUtilities;

public class AppLauncher {
    public static void main(String[] args) {
        // This is the standard way to start a Swing application
        SwingUtilities.invokeLater(() -> {
            // This creates our new refactored window
            MainFrameView mainApp = new MainFrameView();
            mainApp.setVisible(true);
        });
    }
}