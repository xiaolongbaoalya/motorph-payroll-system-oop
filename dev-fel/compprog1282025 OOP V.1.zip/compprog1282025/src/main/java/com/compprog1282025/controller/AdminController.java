package com.compprog1282025.controller;

public class AdminController {
    public void viewEmployeeInfo(int empNum) {}
    public void generatePayrollForAll() {}
}