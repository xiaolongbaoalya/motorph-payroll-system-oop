/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.compprog1282025.gui;

/**
 *
 * @author grazi
 */
import com.compprog1282025.util.DialogsHelper;
import com.compprog1282025.util.ScreenManager;
import com.compprog1282025.util.UIStyles;
import javax.swing.*;
import java.awt.*;

public class LoginDialog extends JDialog {
    private JTextField userField;
    private JPasswordField passField;
    private boolean isAdmin;
    private JFrame parentFrame; // Store the frame to pass to the ScreenManager

    public LoginDialog(JFrame parent, String title, boolean isAdmin) {
        super(parent, title, true);
        this.parentFrame = parent;
        this.isAdmin = isAdmin;
        
        setLayout(new BorderLayout(10, 10));
        setSize(350, 250);
        setLocationRelativeTo(parent);

        // UI Panel
        JPanel panel = new JPanel(new GridLayout(3, 2, 10, 10));
        panel.setBorder(BorderFactory.createEmptyBorder(20, 20, 20, 20));

        panel.add(new JLabel("Username:"));
        userField = new JTextField();
        panel.add(userField);

        panel.add(new JLabel("Password:"));
        passField = new JPasswordField();
        panel.add(passField);

        JButton loginBtn = new JButton("Login");
        UIStyles.styleButton(loginBtn);
        
        // Action Listener for the Login Button
        loginBtn.addActionListener(e -> handleLogin());

        add(panel, BorderLayout.CENTER);
        add(loginBtn, BorderLayout.SOUTH);
    }

    private void handleLogin() {
        String user = userField.getText();
        String pass = new String(passField.getPassword());

        if (isAdmin) {
            // Admin Credentials Check
            if (user.equals("admin") && pass.equals("admin123")) {
                DialogsHelper.showInfo(this, "Admin Login Successful!");
                dispose(); // Close the dialog
                // Successfully pass the frame to switch to Admin Menu
                ScreenManager.showPanel(parentFrame, new AdminMenuView(parentFrame)); 
            } else {
                DialogsHelper.showError(this, "Invalid Admin Credentials");
            }
        } else {
            // Employee Credentials Check
            if (user.equals("user") && pass.equals("user123")) {
                DialogsHelper.showInfo(this, "Employee Login Successful!");
                dispose(); // Close the dialog
                // Successfully pass the frame to switch to Employee Dashboard
                ScreenManager.showPanel(parentFrame, new EmployeeDashboardView(parentFrame, user)); 
            } else {
                DialogsHelper.showError(this, "Invalid Employee Credentials");
            }
        }
    }
}