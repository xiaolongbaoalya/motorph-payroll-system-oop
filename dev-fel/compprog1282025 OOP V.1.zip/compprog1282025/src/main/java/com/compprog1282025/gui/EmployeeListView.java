/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.compprog1282025.gui;

/**
 *
 * @author grazi
 */
import com.compprog1282025.util.ScreenManager;
import com.compprog1282025.util.UIStyles;
import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import java.awt.*;

public class EmployeeListView extends JPanel {
    private JTable employeeTable;
    private DefaultTableModel tableModel;

    // 1. ADD 'JFrame frame' here so we can pass it to the ScreenManager
    public EmployeeListView(JFrame frame) { 
        setLayout(new BorderLayout(10, 10));
        setBorder(BorderFactory.createEmptyBorder(20, 20, 20, 20));
        setBackground(Color.WHITE);

        // Header
        JLabel header = new JLabel("Employee Registry", SwingConstants.CENTER);
        header.setFont(new Font("Segoe UI", Font.BOLD, 22));
        add(header, BorderLayout.NORTH);

        // Table Section
        String[] columns = {"ID", "Last Name", "First Name", "Position", "Status"};
        tableModel = new DefaultTableModel(columns, 0);
        employeeTable = new JTable(tableModel);
        
        tableModel.addRow(new Object[]{"10001", "Crisostomo", "Jose", "CEO", "Regular"});
        tableModel.addRow(new Object[]{"10002", "Mata", "Christian", "Manager", "Regular"});

        JScrollPane scrollPane = new JScrollPane(employeeTable);
        add(scrollPane, BorderLayout.CENTER);

        // Bottom Buttons
        JPanel buttonPanel = new JPanel(new FlowLayout(FlowLayout.RIGHT));
        JButton backBtn = new JButton("Back to Menu");
        UIStyles.styleButtonSmall(backBtn);
        
        buttonPanel.add(backBtn);
        add(buttonPanel, BorderLayout.SOUTH);

        // 2. UPDATED NAVIGATION: Pass the frame and the next view
        backBtn.addActionListener(e -> {
            ScreenManager.showPanel(frame, new AdminMenuView(frame));
        });
    }
}