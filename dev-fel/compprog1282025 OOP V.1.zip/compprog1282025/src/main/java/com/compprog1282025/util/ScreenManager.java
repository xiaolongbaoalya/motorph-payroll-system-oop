/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.compprog1282025.util;

/**
 *
 * @author grazi
 */
import javax.swing.*;
import java.awt.*;

public class ScreenManager {
    public static void showPanel(JFrame frame, JPanel panel) {
        if (frame == null) return;
        
        frame.getContentPane().removeAll();
        frame.setLayout(new BorderLayout());
        frame.add(panel, BorderLayout.CENTER);
        
        frame.revalidate();
        frame.repaint();
    }
}