/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.compprog1282025.util;

/**
 *
 * @author grazi
 */
import java.awt.Color;
import javax.swing.JButton;

public class UIStyles {
    public static final Color PRIMARY_COLOR = new Color(0x1c3680); // MotorPH Blue or so i thought

    public static void styleButton(JButton btn) {
        btn.setBackground(PRIMARY_COLOR);
        btn.setForeground(Color.WHITE);
        btn.setFocusPainted(false);
    }

    public static void styleButtonSmall(JButton btn) {
        btn.setBackground(Color.GRAY);
        btn.setForeground(Color.WHITE);
        btn.setFocusPainted(false);
    }
}