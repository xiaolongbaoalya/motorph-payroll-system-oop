/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.compprog1282025.ui.gui.controllers;

import com.compprog1282025.service.ITService;
import com.compprog1282025.ui.gui.util.AlertHelper;
import com.compprog1282025.ui.gui.util.SceneSwitcher;
import com.compprog1282025.ui.gui.util.SessionContext;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.scene.Node;
import javafx.scene.control.Label;
import javafx.scene.control.TextArea;
import javafx.scene.control.ChoiceDialog;
import javafx.scene.control.TextInputDialog;
import javafx.stage.Stage;

import java.io.IOException;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.Arrays;
import java.util.List;

/**
 *
 * @author grazi
 */

public class ITDashboardController extends BaseController {

    @FXML private Label systemStatusLabel;
    @FXML private Label databasePathLabel;
    @FXML private TextArea consoleLog;

    // The Backend Service that does the real work
    private final ITService itService = new ITService();

    @FXML
    public void initialize() {
        systemStatusLabel.setText("System Online");
        databasePathLabel.setText("Active Database: src/main/resources/data/");
        logToConsole("IT Admin Session Started for Hernandez.");
    }

    @FXML
    private void handleLogout(ActionEvent event) {
        SessionContext.getInstance().clear();
        logToConsole("Session cleared. Redirecting to login...");
        Stage stage = (Stage) ((Node) event.getSource()).getScene().getWindow();
        SceneSwitcher.switchTo(stage, "/com/compprog1282025/ui/gui/views/auth/Login.fxml");
    }

    @FXML
    private void handleSystemAudit() {
        logToConsole("Starting Database Cross-Reference Audit...");
        // The service now returns the error message as a String, so no try-catch needed!
        String report = itService.runIntegrityAudit();
        logToConsole(report);
        AlertHelper.showInfo("Integrity Audit", report);
    }

    @FXML
    private void handleSystemHealth() {
        logToConsole("Scanning system file status...");
        String healthReport = itService.getSystemHealth();
        logToConsole(healthReport);

        if (healthReport.contains("EXCELLENT")) {
            systemStatusLabel.setText("System: Healthy");
            systemStatusLabel.setStyle("-fx-text-fill: green;");
        } else {
            systemStatusLabel.setText("System: Warning");
            systemStatusLabel.setStyle("-fx-text-fill: red;");
        }
        AlertHelper.showInfo("Health Report", healthReport);
    }

    @FXML
    private void handleDatabaseTools() {
        logToConsole("Optimizing database storage (Trimming & Cleaning)...");
        try {
            itService.optimizeDatabase();
            logToConsole("[SUCCESS] All CSV files have been trimmed and optimized.");
            AlertHelper.showInfo("Database Tools", "Maintenance finished. Files are now clean.");
        } catch (IOException e) {
            logToConsole("[ERROR] Optimization failed: " + e.getMessage());
        }
    }

    @FXML
    private void handleUserManagement() {
        List<String> userList = Arrays.asList("garcia", "lim", "aquino", "reyes", "hernandez");

        ChoiceDialog<String> dialog = new ChoiceDialog<>("garcia", userList);
        dialog.setTitle("IT User Management");
        dialog.setHeaderText("Reset Employee Password");
        dialog.setContentText("Select user to reset:");

        dialog.showAndWait().ifPresent(username -> {
            TextInputDialog passwordDialog = new TextInputDialog();
            passwordDialog.setTitle("Reset Password");
            passwordDialog.setHeaderText("Setting new password for: " + username);
            passwordDialog.setContentText("Enter new password:");

            passwordDialog.showAndWait().ifPresent(newPass -> {
                if (!newPass.trim().isEmpty()) {
                    try {
                        // CALLING THE BACKEND SERVICE
                        itService.resetUserPassword(username, newPass);
                        logToConsole("[SUCCESS] Password reset for " + username + " processed by ITService.");
                        AlertHelper.showInfo("Success", "Password updated successfully via Backend.");
                    } catch (IOException e) {
                        logToConsole("[ERROR] Failed to update password: " + e.getMessage());
                        AlertHelper.showError("Update Failed", "Could not write to users.csv");
                    }
                }
            });
        });
    }

    @FXML
    private void handleDatabaseBackup() {
        logToConsole("Initializing System Backup...");
        try {
            // CALLING THE BACKEND SERVICE
            List<String> backupLogs = itService.performBackup();
            
            for (String log : backupLogs) {
                logToConsole(log);
            }
            
            AlertHelper.showInfo("Backup Complete", "System data saved to /backups folder.");
        } catch (IOException e) {
            logToConsole("[CRITICAL] Backup Failed: " + e.getMessage());
            AlertHelper.showError("Backup Failed", e.getMessage());
        }
    }

    private void logToConsole(String message) {
        String time = LocalDateTime.now().format(DateTimeFormatter.ofPattern("HH:mm:ss"));
        if (consoleLog != null) {
            consoleLog.appendText("[" + time + "] " + message + "\n");
        }
        System.out.println(message);
    }
}