package com.compprog1282025.model.employee;

import java.time.LocalDate;
import java.time.LocalTime;

public class Attendance {
	private String attendanceId;
	private int employeeNumber;
	private String firstName;
	private String lastName;
    private LocalDate date;
    private LocalTime timeIn;
    private LocalTime timeOut;

    public Attendance(String attendanceId, int employeeNumber, String firstName, String lastName, LocalDate date, LocalTime timeIn, LocalTime timeOut) {
        this.attendanceId = attendanceId;
    	this.employeeNumber = employeeNumber;
        this.firstName = firstName;
        this.lastName = lastName;
        this.date = date;
        this.timeIn = timeIn;
        this.timeOut = timeOut;
    }
    
    // constructor for time in
    public Attendance(String attendanceId, int employeeNumber, String firstName, String lastName, LocalDate date, LocalTime timeIn) {
    	this.attendanceId = attendanceId;
    	this.employeeNumber = employeeNumber;
        this.firstName = firstName;
        this.lastName = lastName;
        this.date = date;
        this.timeIn = timeIn;
        this.timeOut = null;
    }

    public String getAttendanceId() {
    	return attendanceId;
    }
    public void setAttendanceId(String attendanceId) {
    	this.attendanceId = attendanceId;
    }

    public int getEmployeeNumber() {
		return employeeNumber;
	}
	public void setEmployeeNumber(int employeeNumber) {
		this.employeeNumber = employeeNumber;
	}

	public String getFirstName() {
		return firstName;
	}
	public void setFirstName(String firstName) {
		this.firstName = firstName;
	}

	public String getLastName() {
		return lastName;
	}
	public void setLastName(String lastName) {
		this.lastName = lastName;
	}

	public LocalDate getDate() {
		return date;
	}
	public void setDate(LocalDate date) {
		this.date = date;
	}

	public LocalTime getTimeIn() {
		return timeIn;
	}
	public void setTimeIn(LocalTime timeIn) {
		this.timeIn = timeIn;
	}

	public LocalTime getTimeOut() {
		return timeOut;
	}
	public void setTimeOut(LocalTime timeOut) {
		this.timeOut = timeOut;
	}


	@Override
    public String toString() {
		return String.format("Employee [%d]: %s %s\nDate: %s\nTime In: %s\nTime Out: %s",
				employeeNumber, firstName, lastName, date, timeIn, timeOut);
    }
}
