package com.compprog1282025.dao;

import java.io.FileReader;
import java.util.ArrayList;
import com.opencsv.CSVReader;

import com.compprog1282025.model.user.*;

/*
 * Testing accounts, pw is hashed when stored in csv take note
 * username, password, employee num, role, enabled
 * garcia, password123, 10001, Admin, true
 * lim, password123, 10002, HR, true
 * aquino, password123, 10003, IT, true
 * reyes, password123, 10004, Finance, true
 * hernandez, password123, 10005, Operations, true
 * 
 */

public class UserDAO implements DAO<User, Integer> {
	public static final String USER_CSV_PATH = "data/users.csv";
	private ArrayList<User> userList;

	public UserDAO() {
		this.userList = new ArrayList<>();
	}
	
	@Override
	public void loadData() {
		userList.clear();
		String filepath = USER_CSV_PATH;
		try (CSVReader reader = new CSVReader(new FileReader(filepath))) {
			String[] line;
			reader.readNext();
			
			while ((line = reader.readNext()) != null) {
				String username = line[0];
				String passwordHash = line[1];
				int employeeNumber = Integer.valueOf(line[2]);
				String roleStr = line[3];
				String enStr = line[4];
				boolean enabled = true;
				if (enStr.equalsIgnoreCase("false")) {
					enabled = false;
				}
				//TODO: Add other roles into switch case
				switch (roleStr.toLowerCase()) {
				case "admin":
					this.userList.add(new AdminUser(username, passwordHash, employeeNumber, enabled));
					break;
				case "hr":
					this.userList.add(new HRUser(username, passwordHash, employeeNumber, enabled));
					break;
				case "finance":
					this.userList.add(new FinanceUser(username, passwordHash, employeeNumber, enabled));
					break;
				default:
					this.userList.add(new OperationsUser(username, passwordHash, employeeNumber, enabled));
				}
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
	    System.out.println("System: Initial users loaded for login testing.");
	}
	
	public User findByUsername(String username) {
		for(int i = 0; i < userList.size(); i++) {
			User current = userList.get(i);
			if(current.getUsername().equalsIgnoreCase(username)) {
				return current;
			}
		}
		return null;
	}
	
	@Override
	public void saveData() {
		
	}
	
	@Override
	public void insert(User user) {
		this.userList.add(user);
	}
	
	//TODO: Update by looping through userList to find user based on employeeNumber
	@Override
	public void update(User user) {
		
	}
	
	//TODO: Delete from userList based on employeeNumber
	@Override
	public void delete(Integer employeeNumber) {
		
	}
	

	@Override
	public User findById(Integer employeeNumber) {
		for(int i = 0; i < userList.size(); i++) {
			User current = userList.get(i);
			if(current.getEmployeeNumber() == employeeNumber.intValue()) {
				return current;
			}
		}
		return null;
	}
	
	@Override
	public ArrayList<User> getAll() {
		return userList;
	}
}
