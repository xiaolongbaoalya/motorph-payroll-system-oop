package com.compprog1282025.service;

import java.time.LocalDateTime;
import org.mindrot.jbcrypt.BCrypt;

import com.compprog1282025.dao.UserDAO;
import com.compprog1282025.model.user.*;

public class AuthService {
	private UserDAO userDao;
	
	public AuthService(UserDAO userDao) {
		this.userDao = userDao;
	}
	
	public Session login(String username, String password) {
		
		User loginUser = userDao.findByUsername(username);
		if (loginUser != null && BCrypt.checkpw(password, loginUser.getPasswordHash())) {
			Session session = new Session(loginUser, LocalDateTime.now());
			return session;
		}
		return new Session(false);
		
	}
	
}
