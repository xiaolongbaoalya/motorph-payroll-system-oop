package com.compprog1282025.main;

import java.util.ArrayList;
import java.util.Scanner;

import org.mindrot.jbcrypt.BCrypt;

import com.compprog1282025.dao.*;
import com.compprog1282025.model.employee.*;
import com.compprog1282025.model.user.*;
import com.compprog1282025.model.interfaces.*;
import com.compprog1282025.service.*;
import com.compprog1282025.ui.terminal.*;

public class Main {
	public static void main(String[] args) {
		System.out.println("Java is looking for files in: " + System.getProperty("user.dir"));
		try(Scanner scanner = new Scanner(System.in)) {
			// Load all DAO
			EmployeeDAO employeeDao = new EmployeeDAO();
			AttendanceDAO attendanceDao = new AttendanceDAO();
			UserDAO userDao = new UserDAO();
			LeaveDAO leaveDao = new LeaveDAO();
			
			// Load services
			EmployeeService empSvc = new EmployeeService(employeeDao);
			AttendanceService attSvc = new AttendanceService(attendanceDao);
			FinanceService fncSvc = new FinanceService(attSvc);
			LeaveService leaveSvc = new LeaveService(leaveDao);
			
			// Load menus
			MainMenu mainMenu = new MainMenu();
			EmployeeMenu empMenu = new EmployeeMenu(empSvc, attSvc, fncSvc, leaveSvc);
			HRMenu hrMenu = new HRMenu(empSvc);
			FinanceMenu finMenu = new FinanceMenu(fncSvc, empSvc);
			
			
			employeeDao.loadData();
			attendanceDao.loadData();
			userDao.loadData();
			
			AuthService auth = new AuthService(userDao);
			
			Employee currEmp = null;
			Role role = null;
			mainMenu.displayHeader("MotorPH Payroll System");
			System.out.print("Username: ");
			String username = scanner.nextLine();
			
			System.out.print("Password: ");
			String password = scanner.nextLine();
			
			Session session = auth.login(username, password);
			if(session != null && session.isActive()) {
				System.out.println("--------------------");
				mainMenu.displayLoginSuccess(session);
				currEmp = empSvc.getEmployee(session.getUser().getEmployeeNumber());
				role = session.getUser().getRole();
			} else {
				mainMenu.displayLoginFail();
			}
			
			String mainChoice = "default";
			
			while(session.isActive()) {
				mainMenu.displayStartMenu(session);
				mainChoice = scanner.nextLine();
				switch (mainChoice.trim()) {
				case "0":
					if(session.getAttendance() != null && session.getAttendance().getTimeOut() == null) {
						attSvc.timeOutAttendance(session, currEmp);
					}
					mainMenu.displayExit();
					session.invalidateSession();
					break;
				case "1":
					empMenu.displayPersonalMenu(session, scanner);
					break;
				case "2":
					if(role.hasPermission(Permission.VIEW_EMPLOYEE)) {
						hrMenu.displayHRMenu(session, scanner);
					} else {
						mainMenu.displayInvalid();
					}
					break;
				case "3":
					if(role == Role.FINANCE) {
						finMenu.displayFinanceMenu(session, scanner);
					} else {
						mainMenu.displayInvalid();
					}
					break;
				default:
					mainMenu.displayInvalid();
				}
			}
			
		} catch (Exception e) {
			e.printStackTrace();
		}
		
	}
	
}
