package com.compprog1282025.dao;

import java.util.ArrayList;
import java.util.List;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.time.LocalDate;

import com.opencsv.CSVReader;
import com.opencsv.CSVWriter;
import com.compprog1282025.model.employee.*;
import com.compprog1282025.service.DateTimeUtil;

public class EmployeeDAO implements DAO<Employee, Integer> {
	public static final String EMPLOYEE_CSV_PATH = "data/employees.csv";
	private List<Employee> employeeList;

	public EmployeeDAO() {
		this.employeeList = new ArrayList<>();
	}
	
	@Override
	public void loadData() {
		employeeList.clear();
		String filepath = EMPLOYEE_CSV_PATH;
		try (CSVReader reader = new CSVReader(new FileReader(filepath))) {
			String[] line;
			reader.readNext();
			while ((line = reader.readNext()) != null) {
				int empNum = Integer.valueOf(line[0]);
				String lastName = line[1];
				String firstName = line[2];
				LocalDate birthday = DateTimeUtil.convertStringToDate(line[3]);
				ContactInfo contact = new ContactInfo(line[4], line[5]);
				GovernmentID govtId = new GovernmentID(line[6], line[7], line[8], line[9]);
				String status = line[10];
				Position position = new Position(line[11], line[12]);
				Employee supervisor = this.findByName(line[13]);
				String supName = "None";
				if (supervisor != null) {
					supName = supervisor.getFullName();
				}
				Compensation comp = new Compensation(
						Double.valueOf(line[14]),
						Double.valueOf(line[15]),
						Double.valueOf(line[16]),
						Double.valueOf(line[17])
						);
				this.employeeList.add(new Employee(empNum, firstName, lastName, birthday, contact, govtId, position, comp, status, supName));
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
	
	@Override
	public void saveData() {
		try (CSVWriter writer = new com.opencsv.CSVWriter(new FileWriter(EMPLOYEE_CSV_PATH))) {
			
			// Write header
	        writer.writeNext(new String[]{
	            "Employee #", "Last Name", "First Name", "Birthday", "Address", "Phone",
	            "SSS #", "Philhealth #", "TIN #", "Pag-ibig #", "Status", "Position", "Department",
	            "Supervisor", "Basic Salary", "Rice Subsidy", "Phone Allowance", "Clothing Allowance"
	        });
	        
	        for (Employee emp : employeeList) {
	            writer.writeNext(new String[]{
	                String.valueOf(emp.getEmployeeNumber()),
	                emp.getLastName(),
	                emp.getFirstName(),
	                DateTimeUtil.convertDateToString(emp.getBirthday()),
	                emp.getContact().getAddress(),
	                emp.getContact().getPhone(),
	                emp.getGovernmentID().getSss(),
	                emp.getGovernmentID().getPhilHealth(),
	                emp.getGovernmentID().getTin(),
	                emp.getGovernmentID().getPagIbig(),
	                emp.getStatus(),
	                emp.getPosition().getJobTitle(),
	                emp.getPosition().getDepartment(),
	                emp.getSupervisorName(),
	                Double.toString(emp.getSalary().getBasicSalary()),
	                Double.toString(emp.getSalary().getRiceSubsidy()),
	                Double.toString(emp.getSalary().getPhoneAllowance()),
	                Double.toString(emp.getSalary().getClothingAllowance())
	            });
	        }

	        System.out.println("Successfully wrote to: " + EMPLOYEE_CSV_PATH);
	        } catch (IOException e) {
	        	e.printStackTrace();
	        }
	}
	
	@Override
	public void insert(Employee employee) {
		employeeList.add(employee);
		try (CSVWriter writer = new com.opencsv.CSVWriter(new FileWriter(EMPLOYEE_CSV_PATH, true))) {
			
			// Write header
			writer.writeNext(new String[]{
	                String.valueOf(employee.getEmployeeNumber()),
	                employee.getLastName(),
	                employee.getFirstName(),
	                DateTimeUtil.convertDateToString(employee.getBirthday()),
	                employee.getContact().getAddress(),
	                employee.getContact().getPhone(),
	                employee.getGovernmentID().getSss(),
	                employee.getGovernmentID().getPhilHealth(),
	                employee.getGovernmentID().getTin(),
	                employee.getGovernmentID().getPagIbig(),
	                employee.getStatus(),
	                employee.getPosition().getJobTitle(),
	                employee.getPosition().getDepartment(),
	                employee.getSupervisorName(),
	                Double.toString(employee.getSalary().getBasicSalary()),
	                Double.toString(employee.getSalary().getRiceSubsidy()),
	                Double.toString(employee.getSalary().getPhoneAllowance()),
	                Double.toString(employee.getSalary().getClothingAllowance())
	            });
		} catch (IOException e) {
			e.printStackTrace();
		}
	}
	
	@Override
	public void update(Employee employee) {
		// loop through userList to find user
		// if employeeNumber found, replace
		for (int i = 0; i < employeeList.size(); i++) {
			if(employeeList.get(i).getEmployeeNumber() == employee.getEmployeeNumber()) {
				System.out.println("employee found");
				employeeList.set(i, employee);
				break;
			}
		}
		saveData();
	}
	
	@Override
	public void delete(Integer employeeNumber) {
		for (int i = 0; i < employeeList.size(); i++) {
			if(employeeList.get(i).getEmployeeNumber() == employeeNumber.intValue()) {
				employeeList.remove(i);
				break;
			}
		}
		saveData();
	}
	
	@Override
	public List<Employee> getAll() {
		return employeeList;
	}
	
	@Override
	public Employee findById(Integer employeeNumber) {
		for(int i = 0; i < employeeList.size(); i++) {
			Employee current = employeeList.get(i);
			if(current.getEmployeeNumber() == employeeNumber.intValue()) {
				return current;
			}
		}
		return null;
	}
	
	public Employee findByName(String fullName) {
		for (int i = 0; i < this.employeeList.size(); i++) {
			Employee current = employeeList.get(i);
			if (current.getFullName().trim().equalsIgnoreCase(fullName.trim())) {
				return current;
			}
		}
		return null;
	}
	
}
