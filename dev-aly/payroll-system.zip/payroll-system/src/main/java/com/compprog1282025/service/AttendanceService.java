package com.compprog1282025.service;

import java.time.Duration;
import java.time.LocalDate;
import java.time.LocalTime;
import java.time.YearMonth;
import java.util.List;
import java.util.Optional;

import com.compprog1282025.dao.AttendanceDAO;
import com.compprog1282025.model.employee.Attendance;
import com.compprog1282025.model.employee.Employee;
import com.compprog1282025.model.user.Session;

public class AttendanceService {
	private AttendanceDAO attendanceDao;
	private LocalDate minAttendanceDate;
    private LocalDate maxAttendanceDate;
    
    public AttendanceService(AttendanceDAO attendanceDao) {
        this.attendanceDao = attendanceDao;
        
        List<Attendance> attendanceList = attendanceDao.getAll();

        Optional<LocalDate> min = attendanceList.stream()
            .map(Attendance::getDate)
            .min(LocalDate::compareTo);

        Optional<LocalDate> max = attendanceList.stream()
            .map(Attendance::getDate)
            .max(LocalDate::compareTo);

        this.minAttendanceDate = min.orElse(LocalDate.MIN);
        this.maxAttendanceDate = max.orElse(LocalDate.MAX);
    }
    
 // Checks if the given date is within the range of recorded attendance dates
    public boolean isWithinAttendanceRange(LocalDate date) {
        return !(date.isBefore(minAttendanceDate) || date.isAfter(maxAttendanceDate));
    }

    //YearMonth version of the above method
    public boolean isWithinAttendanceRange(YearMonth month) {
    LocalDate start = month.atDay(1);
    LocalDate end = month.atEndOfMonth();
    return !(end.isBefore(minAttendanceDate) || start.isAfter(maxAttendanceDate));
    }

    public double calculateMonthlyHours(int employeeNumber, YearMonth month) {
        if (!isWithinAttendanceRange(month)) {
            throw new IllegalArgumentException("No attendance records for the specified month: " + month);
        }
        List<Attendance> attendanceList = attendanceDao.getAll();
        return attendanceList.stream()
                .filter(a -> a.getEmployeeNumber() == employeeNumber)
                .filter(a -> YearMonth.from(a.getDate()).equals(month))
                .mapToDouble(a -> {
                    Duration duration = Duration.between(a.getTimeIn(), a.getTimeOut());
                    // Defensive: if timeOut is before timeIn (should not happen), return 0
                    return duration.isNegative() ? 0 : duration.toMinutes() / 60.0;
                })
                .sum();
    }

    public double calculateFixedWeekHours(int employeeNumber, LocalDate referenceDate) {
        if (!isWithinAttendanceRange(referenceDate)) {
            throw new IllegalArgumentException("No attendance records for the specified date: " + referenceDate);
        }
        LocalDate[] weekRange = calculateFixedWeekRange(referenceDate);
        LocalDate startDate = weekRange[0];
        LocalDate endDate = weekRange[1];
        List<Attendance> attendanceList = attendanceDao.getAll();
        return attendanceList.stream()
        		.filter(a -> a.getEmployeeNumber() == employeeNumber)
            .filter(a -> !a.getDate().isBefore(startDate) && !a.getDate().isAfter(endDate))
            .mapToDouble(a -> {
                Duration duration = Duration.between(a.getTimeIn(), a.getTimeOut());
                return duration.isNegative() ? 0 : duration.toMinutes() / 60.0;
            })
        .sum();
    }

    public LocalDate[] calculateFixedWeekRange(LocalDate referenceDate) {
        // Anchor date: known start of first week in pattern (3-7 June 2024)
        LocalDate anchorStart = LocalDate.of(2024, 6, 3);

        // Calculate days between reference and anchor
        long daysSinceAnchor = Duration.between(anchorStart.atStartOfDay(), referenceDate.atStartOfDay()).toDays();

        // Determine which cycle (0-indexed) the reference date falls into
        long cycleIndex = daysSinceAnchor / 7;  // 5 work days + 2-day gap = 7-day cycle

        // Calculate start of the current cycle
        LocalDate weekStart = anchorStart.plusDays(cycleIndex * 7);
        LocalDate weekEnd = weekStart.plusDays(4);  // 5-day week

        return new LocalDate[]{weekStart, weekEnd};
    }
    
    public void timeInAttendance(Session session, Employee employee) {
    	LocalDate date = LocalDate.now();
    	LocalTime time = LocalTime.now();
    	String attendanceId = Integer.toString(employee.getEmployeeNumber()) + "_" + DateTimeUtil.convertDateToString(date) + "_" + DateTimeUtil.convertTimeToString(time);
    	Attendance attendance = new Attendance(attendanceId, employee.getEmployeeNumber(), employee.getFirstName(), employee.getLastName(), date, time);
    	attendanceDao.insert(attendance);
    	session.setAttendance(attendance);
    }
    
    public void timeOutAttendance(Session session, Employee employee) {
    	LocalTime time = LocalTime.now();
    	Attendance attendance = session.getAttendance();
    	if (attendance.getDate().equals(LocalDate.now())) {
    		attendance.setTimeOut(time);
    	} else {
    		attendance.setTimeOut(attendance.getTimeOut().plusHours(8));
    	}
    	attendanceDao.update(attendance);
    }

}
