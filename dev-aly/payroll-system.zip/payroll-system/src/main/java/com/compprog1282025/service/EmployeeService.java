package com.compprog1282025.service;

import java.util.ArrayList;
import java.util.List;

import com.compprog1282025.dao.EmployeeDAO;
import com.compprog1282025.model.employee.Employee;
import com.compprog1282025.model.user.*;

public class EmployeeService {
    private EmployeeDAO employeeDao;

    public EmployeeService(EmployeeDAO employeeDao) {
        this.employeeDao = employeeDao;
    }

    public Employee getEmployee(int employeeNumber) {
        return employeeDao.findById(employeeNumber);
    }

    public void addEmployee(Employee employee, Session session) throws InvalidAccessException {
    	Role role = session.getUser().getRole();
    	if (role.hasPermission(Permission.CREATE_EMPLOYEE)) {
    		employeeDao.insert(employee);
    	} else {
    		throw new InvalidAccessException("You do not have the permissions to perform this action.");
    	}
    }

    public void updateEmployee(Employee employee, Session session) throws InvalidAccessException {
    	Role role = session.getUser().getRole();
    	if (role.hasPermission(Permission.UPDATE_EMPLOYEE)) {
    		employeeDao.update(employee);
    	} else {
    		throw new InvalidAccessException("You do not have the permissions to perform this action.");
    	}
    }

    public void removeEmployee(int employeeNumber, Session session) throws InvalidAccessException {
    	Role role = session.getUser().getRole();
    	if (role.hasPermission(Permission.DELETE_EMPLOYEE)) {
    		employeeDao.delete(employeeNumber);
    	} else {
    		throw new InvalidAccessException("You do not have the permissions to perform this action.");
    	}
        
    }
    
    public List<Employee> getAllEmployees() {
    	return employeeDao.getAll();
    }
    
    public int getNewId() {
    	List<Employee> empList = employeeDao.getAll();
    	return empList.getLast().getEmployeeNumber() + 1;
    }
    
    
}